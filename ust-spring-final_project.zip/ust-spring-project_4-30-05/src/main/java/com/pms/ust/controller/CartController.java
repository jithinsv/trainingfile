package com.pms.ust.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.email.MyEmail;
import com.ust.pms.model.CartDetail;
import com.ust.pms.model.Product;
import com.ust.pms.service.CartService;
import com.ust.pms.service.ProductService;

@Controller
public class CartController {
	@Autowired
	MyEmail sendingEmailApplication;
	@Autowired
	ProductService productService;
	@Autowired
	CartService cartService;
	
		@RequestMapping("/cartpage")	

		public ModelAndView viewAllCart() {
			String username = null;
			Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (principal instanceof UserDetails) {
				username = ((UserDetails) principal).getUsername();
			}
			List<CartDetail> cartDetails=cartService.getCartDetails(username);
			return new ModelAndView("cartpage","cartDetails",cartDetails);
		}
		@RequestMapping("/delete/{productId}")
		public ModelAndView deleteProduct(@PathVariable("productId")String productId) {
			Integer pId= new Integer(productId);
			 Product productDetails=productService.getProduct(pId);
			  CartDetail cartDetails= cartService.getCart(pId);
			if(cartDetails.getQuantityOnHand()>=0) {
				
				productDetails.setQuantityOnHand(productDetails.getQuantityOnHand());
				int stock= cartDetails.getQuantityOnHand();
				productDetails= new Product(cartDetails.getProductId(), cartDetails.getProductName(),productDetails.getQuantityOnHand()+stock,cartDetails.getPrice());
				
				//if(cartDetails.getProductId()==)
				productService.saveProduct(productDetails);}
				
				       			    
					
			cartService.deleteItem(pId);
			
			ModelAndView view=new ModelAndView();
			view.addObject("productId",productId);
			return new ModelAndView("redirect:/cartpage");
		}
		
			//modelAndView.setViewName("redirect:/viewProductList");
		
		@RequestMapping("/update/cart/{productId}")
		public ModelAndView updateProduct(@PathVariable("productId") int productId) 
		{
			ModelAndView modelAndView= new ModelAndView();
			modelAndView.setViewName("redirect:/cartpage");
			  int pId=productId;
			  
			  
			  String username = null;
				Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
				if (principal instanceof UserDetails) {
					username = ((UserDetails) principal).getUsername();
				}
			  Product productDetails=productService.getProduct(pId);
			  CartDetail cartDetails= cartService.getCart(pId);
			if(cartDetails.getQuantityOnHand()>0) {
				
				productDetails.setQuantityOnHand(productDetails.getQuantityOnHand()+1);
				int stock= cartDetails.getQuantityOnHand()-1;
				cartDetails= new CartDetail(productDetails.getProductId(), productDetails.getProductName(),stock,productDetails.getPrice()*stock,username);
				
				//if(cartDetails.getProductId()==)
				cartService.saveCart(cartDetails);}
				else {
					String msg="out of stock";
					System.out.println(msg);
					modelAndView.addObject("msg",msg);
					//modelAndView.setViewName("redirect:/viewProductList");
				       			    
					
				}
			return modelAndView;
		}
		@RequestMapping("/update/cart/add/{productId}")
		public ModelAndView updateCartAdd(@PathVariable("productId") int productId) 
		{
			ModelAndView modelAndView= new ModelAndView();
			modelAndView.setViewName("redirect:/cartpage");
			  int pId=productId;
			  String username = null;
				Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
				if (principal instanceof UserDetails) {
					username = ((UserDetails) principal).getUsername();
				}
			  Product productDetails=productService.getProduct(pId);
			  CartDetail cartDetails= cartService.getCart(pId);
			if(cartDetails.getQuantityOnHand()>0) {
				
				productDetails.setQuantityOnHand(productDetails.getQuantityOnHand()-1);
				int stock= cartDetails.getQuantityOnHand()+1;
				cartDetails= new CartDetail(productDetails.getProductId(), productDetails.getProductName(),stock,productDetails.getPrice()*stock,username);
				
				//if(cartDetails.getProductId()==)
				cartService.saveCart(cartDetails);}
				else {
					String msg="out of stock";
					System.out.println(msg);
					modelAndView.addObject("msg",msg);
					//modelAndView.setViewName("redirect:/viewProductList");
				       			    
					
				}
			return modelAndView;
			
			
		}
		@RequestMapping("/updateCartItem")
		public String updateCartItem(CartDetail cartDetail) {
			
			cartService.updateCart(cartDetail);
			return "redirect:/cartpage";
		}
//		@RequestMapping("/buynow")
//		public String buynow(CartDetail cartDetail) {
//			String username = null;
//			Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//			if (principal instanceof UserDetails) {
//				username = ((UserDetails) principal).getUsername();
//			}
//			cartService.deleteCartDetails(username);
//			sendingEmailApplication.sendCart(username);
//			return "/productPortal";
//		}
		
		   @RequestMapping("/buynow")
				public ModelAndView buynow(CartDetail cartDetail) {
			   String username = null;
				Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (principal instanceof UserDetails) {
				username = ((UserDetails) principal).getUsername();
			}
			//List<CartDetail> cartDetails=cartService.getCartDetails(username);
			long numberOfItemsInCartForUser = cartService.totalNumberOfProductInCart(username);	
			System.out.println("numberOfItemsInCartForUser ::::"+ numberOfItemsInCartForUser);
			if(numberOfItemsInCartForUser>0) {
			//CartDetail cartDetails= new CartDetail();
					cartService.deleteCartDetails(username);
					sendingEmailApplication.sendCart(username);
					ModelAndView view =new ModelAndView();
					view.addObject("msg", "Succesfully Placed Your Order!");
					view.setViewName("productPortal");
					return view;
			}
			else {
				ModelAndView view =new ModelAndView();
				view.addObject("msg", "No items!");
				view.setViewName("cartpage");
				System.out.println("no items");
				return view;
				
			}
				}
	
	
}
