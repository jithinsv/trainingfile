package com.ust.pms.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;


import com.ust.pms.model.CartDetail;
import com.ust.pms.model.Product;


public interface CartRepository extends CrudRepository<CartDetail, Integer> {

	public List<CartDetail> findByCartUserName(String cartUserName);
	public List<CartDetail> deleteByCartUserName(String cartUserName);

}
