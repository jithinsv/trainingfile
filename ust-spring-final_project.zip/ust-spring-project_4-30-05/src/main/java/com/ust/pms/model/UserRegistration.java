package com.ust.pms.model;

import lombok.Data;

@Data
public class UserRegistration {

	private String username;
	private String password;
}
