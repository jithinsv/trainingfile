package com.ust.pms.service;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.pms.model.CartDetail;
import com.ust.pms.model.Product;
import com.ust.pms.repository.CartRepository;
import com.ust.pms.repository.ProductRepository;
;
@Service
public class CartService {
	
	@Autowired
	CartRepository cartRepository;
	public List<CartDetail> getCartDetails(String username){
		return (List<CartDetail>)	cartRepository.findByCartUserName(username);
		}
	public List<CartDetail> getCartDetailss(){
		return (List<CartDetail>)	cartRepository.findAll();
		}
	public void deleteItem(Integer productID) {
		cartRepository.deleteById(productID);
	}
	public	CartDetail getCart(Integer productID) {
		Optional<CartDetail> cartDetail =	cartRepository.findById(productID);
		return cartDetail.get();
	}
	public void deleteCartDetails(String username){
		
				cartRepository.deleteAll();
		}
	public void updateCart(CartDetail cartDetail) {
		cartRepository.save(cartDetail);
		
	}
	public boolean isCartExists(int productID) {
		return cartRepository.existsById(productID);
	}
	public long totalNumberOfProductInCart(String username) {		
		return cartRepository.findByCartUserName(username).size();
	}
	/*
	 * public List<Product> getProducts(){ return (List<Product>)
	 * productRespository.findAll(); } public Product getProduct(Integer productID)
	 * { Optional<Product> product = productRespository.findById(productID); return
	 * product.get(); } public void deleteProduct(Integer productID) {
	 * productRespository.deleteById(productID); } public void updateProduct(Product
	 * product) { productRespository.save(product);
	 * 
	 * } public boolean isProductExists(int productID) { return
	 * productRespository.existsById(productID); }
	 */
	public void saveCart(CartDetail cartDetails) {
		cartRepository.save(cartDetails);
	// TODO Auto-generated method stub
		
	}
}
