package com.ust.pms.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.pms.model.Product;
import com.ust.pms.repository.ProductRepository;
@Service
public class ProductService {
	@Autowired
	ProductRepository productRepository;
	public void saveProduct(Product product) {
		productRepository.save(product);
	}
	public List<Product> getProducts(){
	return (List<Product>)	productRepository.findAll();
	}
	public	Product getProduct(Integer productID) {
		Optional<Product> product =	productRepository.findById(productID);
		return product.get();
	}
	public void deleteProduct(Integer productID) {
		productRepository.deleteById(productID);
	}
	public void updateProduct(Product product) {
		productRepository.save(product);
		
	}
	public boolean isProductExists(int productID) {
		return productRepository.existsById(productID);
	}
}
