package com.ust.pms.model;

import lombok.Data;
@Data
public class Numbers {
private int firstNumber;
private int secondNumber;

	
}
