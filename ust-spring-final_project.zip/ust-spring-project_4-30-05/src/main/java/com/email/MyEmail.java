package com.email;

import java.io.File;
import java.io.IOException;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class MyEmail {
	@Autowired
    private JavaMailSender javaMailSender;
	
	
	public void sendEmail(String emailreceieve) {
		/*
		 * String username=null; Object
		 * principal=SecurityContextHolder.getContext().getAuthentication().getPrincipal
		 * (); if(principal instanceof UserDetails) { username =
		 * ((UserDetails)principal).getUsername(); System.out.println("username is "+
		 * username); }
		 */
		//System.out.println(username+ "------------------------------------------------------------------------");
        SimpleMailMessage msg = new SimpleMailMessage();
        String neededUsername=emailreceieve.split("@")[0].trim();
        msg.setTo(emailreceieve);
       
        msg.setSubject("Congrats!!");
        msg.setText("Hi "+ neededUsername+","+ "\n\n\t\t "+ " Successfully Created Your Account" +"\r\n\n"+"Thanks,"+ "\n\n\t\t "+"ProductPortalTeam"  );

        javaMailSender.send(msg);

    }
	
	
	void sendEmailWithAttachment() throws MessagingException, IOException {

        MimeMessage msg = javaMailSender.createMimeMessage();

        // true = multipart message
        MimeMessageHelper helper = new MimeMessageHelper(msg, true);

        helper.setTo("email address to whom you send the mail");

        helper.setSubject("Testing from Spring Boot");

        // default = text/plain
        //helper.setText("Check attachment for image!");

        // true = text/html
        helper.setText("<h1>Check attachment for image!</h1>", true);

		// hard coded a file path
        FileSystemResource file = new FileSystemResource(new File("C:/Users\\1302143\\Desktop\\ssl4.png"));

        helper.addAttachment("ssl4.png", file);

        javaMailSender.send(msg);

    }

	public void sendCart(String username) {
		SimpleMailMessage msg = new SimpleMailMessage();
        String neededUsername=username.split("@")[0].trim();
        msg.setTo(username);
       
        msg.setSubject("You bought!!");
        msg.setText("Hi "+ neededUsername+","+ "\n\n\t\t "+ " You have been succesfully purchased items" + "\r\n\n"+"Thanks,"+ "\n\n "+"ProductPortalTeam" );
       // msg.set("Thanks,"+ "\n\n\t\t "+"ProductPortalTeam");
        javaMailSender.send(msg);
		
	}
	
	
}
