//package com.pms.ust.controller;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//import org.springframework.http.MediaType;
//import org.springframework.test.web.servlet.MvcResult;
//import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
//
//import com.ust.pms.model.CartDetail;
//import com.ust.pms.model.Product;
//import com.ust.pms.service.ProductService;
//
//
//public class ProductControllerTest extends AbstractTest {
//		
//		String uri = "/cart";
//		ProductService productService;
//		private int productId = 0;
//		private String userId = "productportal.mail@.com";
//
//@Before
//@Override
//public void setUp() 
//{
//	super.setUp();
//	}
//
//@After
//public void tearDown() throws Exception {
//		}
//		
//@Test
//public void testAddProduct() throws Exception {
//productId = 1002;
//Product product = new Product(productId, "Test Product", 5, 500);
//			String productString = mapToJson(product);
//			MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post( "/addProduct")
//					.content(productString)
//					.contentType(MediaType.APPLICATION_JSON).accept(MediaType.ALL)).andReturn();
//			int status = mvcResult.getResponse().getStatus();
//			assertEquals(200, status);
//			System.out.println(product+"***************************");
//			mvc.perform(MockMvcRequestBuilders.delete( "/deleteProductById").content(productString)).andReturn();
//			System.out.println(product+"***************************");		
//}
//		
//@Test
//public void testDeleteFromCart() throws Exception {
//			productId = 1001;
//			CartDetail cart = new CartDetail(productId, "Test Product", 5, 500, userId);
//			String productString = mapToJson(cart);
//			
//			//insertion for test
//			mvc.perform(MockMvcRequestBuilders.post( "/cart/"+productId).
//			        content(productString).
//			        contentType(MediaType.APPLICATION_JSON)).andReturn();
//			
////			MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.delete( "/" +productId).accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
////			int status = mvcResult.getResponse().getStatus();
////			assertEquals(200, status);
////			
////			String content = mvcResult.getResponse().getContentAsString();
////			assertEquals(content, "success");
//		}
////@Test
////		public void testGetAllProducts() throws Exception {
////			productId = 1002;
////			CartDetail product = new CartDetail(productId, "Test Product", 5, 500, userId);
////			String productString = mapToJson(product);
////			//insertion for test
////			mvc.perform(MockMvcRequestBuilders.post(uri + "/addProduct").
////			        content(productString).
////			        contentType(MediaType.APPLICATION_JSON)).andReturn();
////			
////			MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri + "/viewAllProducts/" + userId).accept(MediaType.APPLICATION_JSON_VALUE))
////					.andReturn();
////			int status = mvcResult.getResponse().getStatus();
////			assertEquals(200, status);
////			
////			String content = mvcResult.getResponse().getContentAsString();
////			CartDetail[] productList = super.mapFromJson(content, CartDetail[].class);
////			assertTrue(productList.length > 0);
////			
////			//deleting added product for test
////			mvc.perform(MockMvcRequestBuilders.delete(uri + "/delete/"  + userId + "/" +productId)).andReturn();
////		}
////
////@Test
////public void testGetProductById() throws Exception {
////			productId = 1003;
////			CartDetail product = new CartDetail(productId, "Test Product", 5, 500, userId);
////			String productString = mapToJson(product);
////			//insertion for test
////			mvc.perform(MockMvcRequestBuilders.post(uri + "/addProduct").
////			        content(productString).
////			        contentType(MediaType.APPLICATION_JSON)).andReturn();
////			
////			MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri + "/fetchProduct/" + userId + "/" + productId).accept(MediaType.APPLICATION_JSON_VALUE))
////					.andReturn();
////			int status = mvcResult.getResponse().getStatus();
////			assertEquals(302, status);
////			
////			String content = mvcResult.getResponse().getContentAsString();
////			
////			System.out.println("productString = " + productString);
////			System.out.println("content = " + content);
////			
////			// assertEquals(productString, content);
////			assertTrue(!content.isEmpty());
////			
////			//deleting added product for test
////			mvc.perform(MockMvcRequestBuilders.delete(uri + "/delete/"  + userId + "/" +productId)).andReturn();
////		}
//
//
//}
